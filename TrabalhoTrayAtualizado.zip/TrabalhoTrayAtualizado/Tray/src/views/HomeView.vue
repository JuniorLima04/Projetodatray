
<template>
  <div class="container">
    <div class="site-message text-center mt-5">
        <h3 class="mb-3">Seja Bem-Vindo ao <span class="sneaker-world">SneakerWorld!</span></h3>
        <div class="d-flex justify-content-between align-items-center">
           <p>
                <router-link to="/cad">CADASTRE-SE</router-link>
           </p>
          <p>E RECEBA<b> 10% DE DESCONTO</b> NA SUA PRIMEIRA COMPRA.</p>
            <button class="close-btn" type="button">&times;</button>
        </div>
    </div>
</div>

<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container">
        <div class="header-container d-flex align-items-center justify-content-between">
            <div class="logo">
                <h1 class="text-light"><a href="#"><span>SneakerWorld</span></a></h1>
            </div>

            <nav id="navbar" class="navbar">
                <ul>
                    <li><a class="getstarted scrollto" href="/cad">Cadastre-se</a></li>
                    <li><a class="getstarted scrollto" href="/com">Compra</a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav>

        </div>
    </div>
</header>

<section id="hero" class="d-flex align-items-center">
    <img src="../assets/hero-bg.jpg" width="100%" class="img-fluid" alt="Imagem">
    
    <div class="container text-center position-relative"  data-aos="fade-in" data-aos-delay="200">
        <h1>Sua Loja Online Para Compras de Tênis</h1>
        <h2>Aqui você terá uma experiência incrível</h2>
        <a href="#" class="btn-get-started scrollto">Login</a>
    </div>
</section>

<section id="clients" class="clients">
    <div class="container">

        <div class="row">

            <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center" data-aos="zoom-in" data-aos-delay="100">
                <img src="../assets/client-1.png" class="img-fluid" alt="Imagem">
            </div>

            <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center" data-aos="zoom-in" data-aos-delay="200">
                <img src="../assets/client-2.png" class="img-fluid" alt="imagem">
            </div>

            <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center" data-aos="zoom-in" data-aos-delay="300">
                <img src="../assets/client-3.png" class="img-fluid" alt="Imagem">
            </div>

            <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center" data-aos="zoom-in" data-aos-delay="400">
                <img src="../assets/client-4.png" class="img-fluid" alt="Imagem">
            </div>

            <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center" data-aos="zoom-in" data-aos-delay="500">
                <img src="../assets/client-5.png" class="img-fluid" alt="Imagem">
            </div>

            <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center" data-aos="zoom-in" data-aos-delay="600">
                <img src="../assets/client-6.png" class="img-fluid" alt="Imagem">
            </div>

        </div>
    </div>
</section>


<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
</template>

<style>


</style>