<template>
  <div class="container">
    <div class="header-container d-flex align-items-center justify-content-between">
      <div class="logo">
        <h1 class="text-light"><a href="#"><span>SneakerWorld</span></a></h1>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <router-link class="getstarted scrollto" to="/">Home</router-link>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
    </div>

    <div class="card" style="width: 18rem;">
      <img src="https://sneakersul.com.br/cdn/shop/files/nike-sb-dunk-low-chunky-dunky-ben-jerry-1.webp?v=1711918710&width=2048" class="card-img-top" alt="Nike Dunk">
      <div class="card-body">
        <h5 class="card-title">Nike Dunk</h5>
        <p class="card-text">A colaboração inovadora entre Nike e Ben & Jerry's resultou no Nike Dunk Low SB 'Chunky Dunky', inspirado no sabor de sorvete Chunky Monkey Nike SB.</p>
      </div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item">Preço: R$ 900,00</li>
        <li class="list-group-item">Ano: 2023</li>
      </ul>
      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#escolhaEcommerceModal">Comprar</button>
    </div>

    <div id="escolhaEcommerceModal" class="modal fade" tabindex="-1" aria-labelledby="escolhaEcommerceModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form @submit.prevent="finalizePurchase">
            <div class="modal-header">
              <h4 class="modal-title">Preencha o formulário</h4>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" v-model="formData.email" placeholder="Digite o seu email" required>
                <span class="text-danger">{{ emailError }}</span>
              </div>
              <div class="form-group">
                <label for="endereco">Endereço:</label>
                <input type="text" class="form-control" id="endereco" v-model="formData.endereco" placeholder="Digite o seu endereço" required>
                <span class="text-danger">{{ enderecoError }}</span>
              </div>
              <div class="form-group">
                <label for="cidade">Cidade:</label>
                <input type="text" class="form-control" id="cidade" v-model="formData.cidade" placeholder="Ex: Marília" required>
                <span class="text-danger">{{ cidadeError }}</span>
              </div>
              <div class="form-group">
                <label for="estado">Estado:</label>
                <input type="text" class="form-control" id="estado" v-model="formData.estado" placeholder="São Paulo" required>
                <span class="text-danger">{{ estadoError }}</span>
              </div>
              <div class="form-group">
                <label for="complemento">Complemento:</label>
                <textarea class="form-control" id="complemento" v-model="formData.complemento" rows="3" placeholder="ex: ap 302"></textarea>
                <span class="text-danger">{{ complementoError }}</span>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary">Finalizar compra</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Modal de sucesso -->
    <div class="modal fade" id="purchaseSuccessModal" tabindex="-1" aria-labelledby="purchaseSuccessModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Compra realizada!</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>{{ successMessage }}</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import CompraService from '@/services/CompraService';

const formData = ref({
  email: '',
  endereco: '',
  cidade: '',
  estado: '',
  complemento: ''
});

const successMessage = ref('');
const emailError = ref('');
const enderecoError = ref('');
const cidadeError = ref('');
const estadoError = ref('');
const complementoError = ref('');

async function finalizePurchase() {
  // Validar formulário
  if (!validateForm()) {
    return;
  }

  const compraData = {
    Produto: 'Nike Dunk',
    Preco: 900, // Ajustado para número (decimal) conforme necessário
    Email: formData.value.email,
    Cidade: formData.value.cidade,
    Estado: formData.value.estado,
    Complemento: formData.value.complemento // Adicionado complemento
  };

  try {
    await CompraService.create(compraData);
    successMessage.value = 'Compra realizada com sucesso!';
    // Resetar o formulário
    clearForm();
    // Abrir o modal de sucesso
    const successModal = new bootstrap.Modal(document.getElementById('purchaseSuccessModal'));
    successModal.show();
  } catch (error) {
    console.error('Erro durante a compra:', error);
    if (error.response && error.response.data && error.response.data.error === "Email não registrado.") {
      emailError.value = 'Email não registrado. Por favor, registre seu email antes de realizar a compra.';
    }
  }
}

function validateForm() {
  let valid = true;
  emailError.value = '';
  enderecoError.value = '';
  cidadeError.value = '';
  estadoError.value = '';
  complementoError.value = '';

  if (!formData.value.email) {
    emailError.value = 'Por favor, informe seu email.';
    valid = false;
  }
  if (!formData.value.endereco) {
    enderecoError.value = 'Por favor, informe seu endereço.';
    valid = false;
  }
  if (!formData.value.cidade) {
    cidadeError.value = 'Por favor, informe sua cidade.';
    valid = false;
  }
  if (!formData.value.estado) {
    estadoError.value = 'Por favor, informe seu estado.';
    valid = false;
  }

  return valid;
}

function clearForm() {
  formData.value.email = '';
  formData.value.endereco = '';
  formData.value.cidade = '';
  formData.value.estado = '';
  formData.value.complemento = '';
}
</script>

<style scoped>
.container {
  width: 100%;
  margin: 0 auto;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h1 {
  margin-bottom: 0;
}

.text-light {
  color: #fff;
}

.card {
  margin-top: 20px;
}

.card-img-top {
  height: 200px;
  object-fit: cover;
}

.btn-primary {
  margin-top: 10px;
}

.modal-body {
  padding: 20px;
}

.modal-title {
  margin-bottom: 10px;
}

.text-danger {
  color: red;
}

.form-control {
  margin-bottom: 10px;
}

.btn-secondary {
  background-color: #6c757d;
}

.btn-close {
  color: #000;
}
</style>
