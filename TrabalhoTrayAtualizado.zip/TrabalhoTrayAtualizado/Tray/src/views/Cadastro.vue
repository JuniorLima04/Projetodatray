<template>
  <div class="container">
    <div class="header-container d-flex align-items-center justify-content-between">
      <div class="logo">
        <h1 class="text-light"><a href="#"><span>SneakerWorld</span></a></h1>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <router-link class="getstarted scrollto" to="/">Home</router-link>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
    </div>
  </div>
  <div class="container">
    <h2>Cadastro</h2>
    <form @submit.prevent="submitForm">
      <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" v-model="formData.nome" class="form-control" required>
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="formData.email" class="form-control" required>
      </div>
      <div class="form-group">
        <label for="senha">Senha:</label>
        <input type="password" id="senha" v-model="formData.senha" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary">Cadastrar</button>
    </form>
    <p v-if="successMessage" class="mt-3 alert alert-success">{{ successMessage }}</p>
    <p v-if="errorMessage" class="mt-3 alert alert-danger">{{ errorMessage }}</p>
  </div>
</template>

<script>
import PessoaService from '@/services/PessoaService';

export default {
  name: "CadastroPessoa",
  data() {
    return {
      formData: {
        nome: '',
        email: '',
        senha: ''
      },
      successMessage: '',
      errorMessage: ''
    };
  },
  methods: {
    submitForm() {
      PessoaService.create(this.formData)
        .then(response => {
          this.successMessage = 'Cadastro realizado com sucesso!';
          this.errorMessage = '';
          this.resetForm();
        })
        .catch(error => {
          if (error.response && error.response.status === 500) {
            this.errorMessage = 'Erro no servidor ao realizar o cadastro.';
          } else if (error.response && error.response.status === 400) {
            this.errorMessage = 'Erro ao realizar o cadastro. Verifique seus dados.';
          } else {
            this.errorMessage = 'Erro ao realizar o cadastro. Tente novamente mais tarde.';
          }
          this.successMessage = '';
        });
    },
    resetForm() {
      this.formData.nome = '';
      this.formData.email = '';
      this.formData.senha = '';
    }
  }
};
</script>

<style scoped>
.container {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.container {
  width: 100%;
  margin: 0 auto;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h2 {
  margin-bottom: 20px;
  text-align: center;
  color: #333;
}

.form-group {
  margin-bottom: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
  color: #666;
}

input[type="text"],
input[type="email"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

button[type="submit"] {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  border: none;
  border-radius: 5px;
  color: #fff;
  cursor: pointer;
}

.alert {
  padding: 10px;
  border-radius: 5px;
  text-align: center;
  margin-top: 10px;
}

.alert-success {
  background-color: #28a745;
  color: #fff;
}

.alert-danger {
  background-color: #dc3545;
  color: #fff;
}
</style>
